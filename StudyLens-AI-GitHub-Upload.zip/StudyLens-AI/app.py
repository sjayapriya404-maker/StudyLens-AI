import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from pathlib import Path
try:
    from pypdf import PdfReader
except ImportError:
    PdfReader=None

class StudyLensApp:
    def __init__(self, root):
        self.root=root
        root.title("StudyLens AI — On-Device Learning Assistant")
        root.geometry("1000x700")
        self.document_text=""
        tk.Label(root,text="StudyLens AI",font=("Arial",22,"bold"),padx=16,pady=12).pack(anchor="w")
        tk.Label(root,text="Private, document-grounded learning assistant for Snapdragon-powered HP PCs",padx=16).pack(anchor="w")
        bar=tk.Frame(root,padx=16,pady=10); bar.pack(fill="x")
        for label,cmd in [("Upload PDF",self.upload),("Summarize",self.summarize),("Revision Notes",self.notes),("Generate Quiz",self.quiz)]:
            tk.Button(bar,text=label,command=cmd,width=16).pack(side="left",padx=5)
        self.status=tk.Label(root,text="No document loaded.",anchor="w",padx=16); self.status.pack(fill="x")
        self.out=scrolledtext.ScrolledText(root,wrap="word",font=("Arial",11)); self.out.pack(fill="both",expand=True,padx=16,pady=8)
        q=tk.Frame(root,padx=16,pady=10); q.pack(fill="x")
        self.entry=tk.Entry(q); self.entry.pack(side="left",fill="x",expand=True,padx=(0,8))
        tk.Button(q,text="Ask",command=self.ask,width=12).pack(side="right")
        self.out.insert("end","Welcome to StudyLens AI.\nUpload a study PDF to begin.")
    def upload(self):
        if PdfReader is None:
            messagebox.showerror("Missing dependency","Run: pip install -r requirements.txt"); return
        p=filedialog.askopenfilename(filetypes=[("PDF files","*.pdf")])
        if not p:return
        try:
            r=PdfReader(p); self.document_text="\n".join(x.extract_text() or "" for x in r.pages).strip()
            self.status.config(text=f"Loaded: {Path(p).name} | {len(self.document_text)} characters")
            self.show(self.document_text[:12000])
        except Exception as e: messagebox.showerror("PDF error",str(e))
    def need(self):
        if not self.document_text:
            messagebox.showinfo("Upload a document","Please upload a study PDF first."); return False
        return True
    def show(self,t):
        self.out.delete("1.0","end"); self.out.insert("end",t)
    def summarize(self):
        if self.need():
            s=[x.strip() for x in self.document_text.replace("\n"," ").split(".") if x.strip()]
            self.show("SMART SUMMARY\n\n"+".".join(s[:8]))
    def notes(self):
        if self.need():
            x=[a.strip() for a in self.document_text.splitlines() if a.strip()]
            self.show("REVISION NOTES\n\n"+"\n".join("• "+a for a in x[:20]))
    def quiz(self):
        if self.need():
            x=[a.strip() for a in self.document_text.splitlines() if len(a.strip())>20] or [self.document_text[:500]]
            self.show("PRACTICE QUIZ\n\n"+"\n\n".join(f"{i}. Explain the main idea:\n   {a[:350]}" for i,a in enumerate(x[:5],1)))
    def ask(self):
        if self.need():
            q=self.entry.get().strip()
            if not q:return
            terms=[t.lower() for t in q.split() if len(t)>3]
            m=[x for x in self.document_text.splitlines() if any(t in x.lower() for t in terms)]
            self.show(f"QUESTION\n{q}\n\nANSWER\n"+("\n".join(m[:8]) if m else "No direct matching passage found. Try keywords from the study material."))
if __name__=="__main__":
    root=tk.Tk(); StudyLensApp(root); root.mainloop()
