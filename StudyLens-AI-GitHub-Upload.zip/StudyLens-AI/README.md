# StudyLens AI
Private On-Device Learning Assistant for Snapdragon-Powered HP PCs.

## Features
- Local PDF extraction
- Document-grounded Q&A
- Smart summaries
- Revision notes
- Practice quiz generation
- Desktop UI

## Run
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

## Snapdragon / AI Hub roadmap
The MVP is local-first and can be extended with Qualcomm AI Hub or compatible open-source models. Final hardware-acceleration claims should be made only after validation on the target Snapdragon-powered HP PC.

Planned upgrades: local LLM, embeddings/retrieval, Qualcomm AI Hub optimization, hardware benchmarking, citation-aware answers and adaptive quizzes.

Author: S Jayapriya
Institution: SRM Easwari Engineering College
